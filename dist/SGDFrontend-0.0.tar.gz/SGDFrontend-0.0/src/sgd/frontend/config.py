heritage_url = 'http://heritage.yeastgenome.org'
#backend_url = 'http://localhost:6543'
backend_url = 'http://localhost:6541'
#backend_url = 'http://www.yeastgenome.org/webservice'
#backend_url = 'http://sgd-dev.stanford.edu/webservice'

log_directory = None